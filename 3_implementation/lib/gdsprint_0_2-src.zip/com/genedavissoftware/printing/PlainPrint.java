 /*
  
  Copyright (c) 2005, Terrance Gene Davis
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:
  
  *   Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
  *   Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
  *   Neither the name of the Gene Davis Software nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

*/

package com.genedavissoftware.printing;

import java.util.regex.*;

import com.genedavissoftware.printing.backend.*;

/**
 * Prints the given string with no formatting except line 
 * breaks. This class is finished and is not likely to change
 * unless a bug is found.
 */
public class PlainPrint extends GDSPrinting {
	
	/**Testing/example for using PlainPrint*/
	public static void main(String args[]) {
		PlainPrint plain = new PlainPrint();
		try { plain.print("<>Tes>     <ting \n123><>"); } catch (Exception e) {}
	}
	
	
	/**
	 * Print the string.
	 */
	public void print(String s) throws GDSPrintException {
		//first prep the string for the printing
		String toPrint = prepareString(s);
		//now send the prep'ed string to the print preview
		PrintPreview.print(toPrint);
	}
	
	
	/**
	 * Internally all text is converted to HTML
	 */
	private String prepareString(String s) {
		String retval = s;
		
		//replace all < and > with &lt; and &gt; symbols
		Pattern pat1 = Pattern.compile("<");
		Matcher mat1 = pat1.matcher(retval);
		retval = mat1.replaceAll("&lt;");

		Pattern pat2 = Pattern.compile(">");
		Matcher mat2 = pat1.matcher(retval);
		retval = mat2.replaceAll("&gt;");
		
		//Add <font size="0"> to the beginning and </font> to the ending
		
		
		return ("<pre><font size=\"+0\">" + retval + "</font></pre>");
	}
}
