 /*
  
  Copyright (c) 2005, Terrance Gene Davis
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:
  
  *   Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
  *   Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
  *   Neither the name of the Gene Davis Software nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

*/

package com.genedavissoftware.printing;

import java.awt.*;
import java.awt.print.*;
import javax.swing.*;


/**
 * HelloPrint is a very basic "Hello World" for printing in Java. 
 * This code is from:<br>
 * <br>
 * http://www.genedavis.com/library/java_printing/<br>
 * <br>
 * Some information used to create this library is based off 
 * information found here:<br>
 * <br>
 * http://www.developerdotstar.com/community/node/124
 */
public class HelloPrint extends JPanel implements Printable {

	public static void main(String[] args) {
        final JFrame jf = new JFrame("Hello Frame");
    	
        final HelloPrint gds = new HelloPrint();
        gds.setPreferredSize(new Dimension(200,200));
        gds.setMinimumSize(new Dimension(200,200));
        
        jf.getContentPane().add(gds);
        
        jf.setSize(400,400);
        
        //invokeLater() is used as a workaround for a java
        //gui bug.
        SwingUtilities.invokeLater(new Runnable() {
        		public void run() {
        			try {
           			jf.setVisible(true);
           			
           			//get a PrintJob
      				PrinterJob pjob = PrinterJob.getPrinterJob();
        				//set a HelloPrint as the target to print
      				pjob.setPrintable(gds, pjob.defaultPage());
      				//get the print dialog, continue if canel
      				//is not clicked
        				if (pjob.printDialog()) {
        					//print the target (HelloPrint)
        					pjob.print();
        				}
        			} catch (Exception e) {
    	        			e.printStackTrace();
        			}
        		}
        });
	        		
	        
    }
	
	/**
	 * We happen to implement a paint method, but this could be
	 * ignored for components that already to something interesting
	 * on their own.<br>
	 * <br>
	 * This is called by HelloPrint.print(Graphics,PageFormat,int). 
	 * It is not intended to be called directly by the coder.<br>
	 */
	public void paint(Graphics g) {
        super.paint(g);
        g.drawString("Hello world!", 35, 100);
	}

	
	/**
	 * Printable's implementation. This is called as a result of a 
	 * call to PrinterJob.print(). It is not intended to be called 
	 * directly by the coder.
	 */
	public int print(Graphics g, PageFormat pf, int pageIndex) {
		//assume the page exists until proven otherwise
		int retval = Printable.PAGE_EXISTS;
		
		//We only want to deal with the first page.
		//The first page is numbered '0'
		if (pageIndex > 0){
			retval = Printable.NO_SUCH_PAGE;
		} else {
			//setting up the Graphics object for printing
			g.translate((int)(pf.getImageableX()), (int)(pf.getImageableY()));
	    		//populate the Graphics object from HelloPrint's paint() method
			paint(g);
		}
		
	    return retval;
    }
}