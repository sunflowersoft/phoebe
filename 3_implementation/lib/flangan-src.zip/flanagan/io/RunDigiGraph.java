/*
*   Class   RunDigiGraph
*
*   Application to perform a digitization using the class DigiGraph
*
*   WRITTEN BY: Dr Michael Thomas Flanagan
*
*   DATE:	 December 2008
*
*   DOCUMENTATION:
*   See Michael T Flanagan's Java library on-line web pages:
*   http://www.ee.ucl.ac.uk/~mflanaga/java/
*   http://www.ee.ucl.ac.uk/~mflanaga/java/DigiGraph.html
*
*   Copyright (c) 2006 - 2008
*
***********************************************************************/

package flanagan.io;

public class RunDigiGraph {

   public static void main(String[] args) {

        // Create an instance of digigraph
        DigiGraph dg = new DigiGraph();

        // Digitize
        dg.digitize();
   }
}


