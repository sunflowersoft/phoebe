/*      Matrix Example 3

        Illustrates the use of matrices
        with a matrix multiplication example.

        Multiplication uses class Matrix

        Michael Thomas Flanagan

        Created: 8 November 2003
        Updated: 1 May 2005

*/
package flanagan.math;

import flanagan.io.*;

public class MatrixExample3{

    public static void main(String[] args){

        //    Create and fill input arrays for matrix values
        double[][] arraysA = {{3.0,2.0,-1.0},{0.0,4.0,6.0}};
        double[][] arraysB = {{1.0,0.0},{5.0,3.0},{6.0, 4.0}};
        double[][] arraysC = new double[2][2];

        // Create three instances of Matrix
        Matrix matrixA = new Matrix(arraysA);
        Matrix matrixB = new Matrix(arraysB);
        Matrix matrixC = new Matrix(2,2);


        //   Multiplication  C =A.B
        matrixC = matrixA.times(matrixB);

        //   Get result of multriplication
        arraysC = matrixC.getArrayCopy();

        // Output matrixA (A)
	    System.out.println("Matrix A\n");
        for(int i=0; i<2; i++){
            for(int j=0; j<3; j++){
                System.out.print(arraysA[i][j]+"\t");
            }
            System.out.println(" ");
        }
        System.out.println(" ");

        // Output matrixB (B)
	    System.out.println("Matrix B\n");
        for(int i=0; i<3; i++){
            for(int j=0; j<2; j++){
                System.out.print(arraysB[i][j]+"\t");
            }
            System.out.println(" ");
        }
        System.out.println(" ");

        // Output matrixC (C = A.B)
	    System.out.println("Matrix C = A.B\n");
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                System.out.print(arraysC[i][j]+"\t");
            }
            System.out.println(" ");
        }
        System.out.println(" ");
    }

}



