/*      Matrix Example 2

        Illustrates the use of matrices
        with a matrix multiplication example.

        All matrix initialised using [int variable][int variable]

        Michael Thomas Flanagan

        Created: 8 November 2003
        Updated: 1 May 2005

*/
package flanagan.math;

import flanagan.io.*;

public class MatrixExample2{

    public static void main(String[] args){

        // Matrix dimensions
        int nRowsMatrixA = 2;  //  number of rows for matrix A
	    int nColsMatrixA = 3;  //  number of columns for matrix A
	    int nRowsMatrixB = 3;  //  number of rows for matrix B
	    int nColsMatrixB = 2;  //  number of columns for matrix B
	    int nRowsMatrixC = 2;  //  number of rows for matrix C
	    int nColsMatrixC = 2;  //  number of columns for matrix C

        //    Create matrices
        double[][] matrixA = new double[nRowsMatrixA][nColsMatrixA];
        double[][] matrixB = new double[nRowsMatrixB][nColsMatrixB];
        double[][] matrixC = new double[nRowsMatrixC][nColsMatrixC];

        //    Fill Matrices
        matrixA[0][0] = 3.0;
    	matrixA[0][1] = 2.0;
    	matrixA[0][2] = -1.0;
    	matrixA[1][0] = 0.0;
    	matrixA[1][1] = 4.0;
    	matrixA[1][2] = 6.0;

    	matrixB[0][0] = 1.0;
    	matrixB[0][1] = 0.0;
    	matrixB[1][0] = 5.0;
    	matrixB[1][1] = 3.0;
    	matrixB[2][0] = 6.0;
	    matrixB[2][1] = 4.0;

        //   Multiplication  C =A.B
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                for(int k=0; k<3; k++){
                    matrixC[i][j] += matrixA[i][k]*matrixB[k][j];
                }
            }
        }

        // Output matrixA(A)
	    System.out.println("Matrix A\n");
        for(int i=0; i<2; i++){
            for(int j=0; j<3; j++){
                System.out.print(matrixA[i][j]+"\t");
            }
            System.out.println(" ");
        }
        System.out.println(" ");

        // Output matrixB (B)
	    System.out.println("Matrix B\n");
        for(int i=0; i<3; i++){
            for(int j=0; j<2; j++){
                System.out.print(matrixB[i][j]+"\t");
            }
            System.out.println(" ");
        }
        System.out.println(" ");

        // Output matrixC (C = A.B)
	    System.out.println("Matrix C = A.B\n");
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                System.out.print(matrixC[i][j]+"\t");
            }
            System.out.println(" ");
        }
        System.out.println(" ");
    }

}



