/*      PrismCouplerExample
*
*       An example program illustrating some of the methods
*       in the class PrismCoupler
*
*       This example calculates the refractive index of the
*       ferric phosphate thin layer 'glass' core of an
*       asymmetric slab waveguide with a glass substrate
*       and a coupling fluid superstrate.
*
*       Reference:  A N Sloper and M T Flanagan
*                   Metal phosphate planar waveguides for biosensors
*                   Applied Optics, 33, (1994) 4230-4240
*
*       M T Flanagan April 2006
*/
package flanagan.optics;

import flanagan.math.*;

public class PrismCouplerExample{


    public static void main(String[] args){

        // COUPLING EXPERIMENT DETAILS
        // Core layer thicknesses (metres)
        double[] thicknesses = {146.21e-9, 146.33e-9, 173.22e-9, 200.82e-9, 213.96e-9, 281.58e-9, 312.91e-9, 312.98e-9};

        // TE mode coupling angles (degrees)
        double[] anglesTE = {2.91, 3.41, 4.68, 6.12, 6.79, 10.42, 10.86, 11.31};

        // TE mode numbers
        double[] modeTE = {0, 0, 0, 0, 0, 0, 0, 0};

        // TM mode coupling angles (degrees)
        double[] anglesTM = {1.20, 1.47, 2.91, 4.12, 4.99, 8.63, 9.22, 9.70};

        // TM mode numbers
        double[] modeTM = {0, 0, 0, 0, 0, 0, 0, 0};

        // Wavelength (metres)
        double wavelength = 632.8e-9;

        // Prism angle alpha (degrees)
        double prismAngle = 60.0D;

        // Prism refractive index at 632.8 nm
        double prismRefractiveIndex = 1.78485;

        // Substrate refractive index at 632.8 nm
        double substrateRefractiveIndex = 1.520;

        // Superstrate refractive index at 632.8 nm
        double superstrateRefractiveIndex = 1.516;

        // PRISM COUPLER INSTANCE
        // Create an instance of PrismCoupler
        PrismCoupler pc = new PrismCoupler();

        // Set wavelength
        pc.setWavelength(wavelength);

        // Set prism angle, alpha
        pc.setPrismAngleAlpha(prismAngle);

        // Set prism refractive index
        pc.setPrismRefractiveIndex(prismRefractiveIndex);

        // Set substrate refractive index
        pc.setSubstrateRefractiveIndex(substrateRefractiveIndex);

        // Set superstrate refractive index
        pc.setSuperstrateRefractiveIndex(superstrateRefractiveIndex);

        // Enter TE mode data
        pc.enterTEmodeData(thicknesses, anglesTE, modeTE);

        // Enter TM mode data
        pc.enterTMmodeData(thicknesses, anglesTM, modeTM);

        // RESULTS OF CORE LAYER REFRACTIVE INDEX DETERMINATION
        // Get the mean core refractive index
        double meanCoreRefractiveIndex = pc.getMeanCoreFilmRefractiveIndex();
        System.out.println("Mean core refractive index = " + meanCoreRefractiveIndex);

        // Get the standard deviation of the core refractive index
        double sdCoreRefractiveIndex = pc.getStandardDeviationCoreFilmRefractiveIndex();
        System.out.println("Standard deviation core refractive index = " + sdCoreRefractiveIndex);

        // Plot the resulting dispersion curve
        pc.plotFittedDispersionCurves();

        // Get the individual TE mode calculated core refractive indices
        double[] CoreRefractiveIndicesTE = pc.getTEmodeCoreFilmRefractiveIndices();
        System.out.println("Individual TE mode calculated core refractive indices");
        Fmath.print(CoreRefractiveIndicesTE);

        // Get the individual TM mode calculated core refractive indices
        double[] CoreRefractiveIndicesTM = pc.getTMmodeCoreFilmRefractiveIndices();
        System.out.println("Individual TM mode calculated core refractive indices");
        Fmath.print(CoreRefractiveIndicesTM);
    }

}


